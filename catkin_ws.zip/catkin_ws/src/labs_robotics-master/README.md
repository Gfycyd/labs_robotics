# urdf_lab
	$ roslaunch urdf_tutorial display.launch model:=urdf/katya_bot.urdf

for MAC before roslaunch: 
	export LC_NUMERIC="en_US.UTF-8"







