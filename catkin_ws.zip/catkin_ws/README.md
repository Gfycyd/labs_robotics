# You need to download zip package and unzip it, next do catkin_make in catkin_ws directory and then go to directory urdf_labs_master and do commands
# urdf_lab
	$ roslaunch urdf_tutorial display.launch model:=urdf/katya_bot.urdf

for MAC before roslaunch: 
	export LC_NUMERIC="en_US.UTF-8"







